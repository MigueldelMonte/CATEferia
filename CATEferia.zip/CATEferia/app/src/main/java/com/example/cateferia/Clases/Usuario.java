package com.example.cateferia.Clases;

public class Usuario {

    private String Nombre, Matricula, Password;

//    Contructor sin parametros
    public  Usuario(){}
//    Constructor con parametros
    public Usuario(String Nombre, String Matricula, String Password) {
        this.Nombre = Nombre;
        this.Matricula = Matricula;
        this.Password = Password;
    }
//    Declaracion de getters y setter

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getMatricula() {
        return Matricula;
    }

    public void setMatricula(String Matricula) {
        this.Matricula = Matricula;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }
}
