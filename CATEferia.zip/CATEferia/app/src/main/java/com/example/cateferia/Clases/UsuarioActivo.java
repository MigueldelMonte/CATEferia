package com.example.cateferia.Clases;

public class UsuarioActivo {
    private static Usuario usuario_activo;
}
