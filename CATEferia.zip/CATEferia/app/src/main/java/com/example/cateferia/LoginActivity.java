package com.example.cateferia;

        import androidx.annotation.NonNull;
        import androidx.appcompat.app.AppCompatActivity;

        import android.app.ProgressDialog;
        import android.content.Intent;
        import android.os.Bundle;
        import android.text.TextUtils;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Toast;

        import com.example.cateferia.Clases.Usuario;
        import com.google.firebase.database.DataSnapshot;
        import com.google.firebase.database.DatabaseError;
        import com.google.firebase.database.DatabaseReference;
        import com.google.firebase.database.FirebaseDatabase;
        import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {

    private Button BotonInicioSes;
    private EditText  log_nmat, log_pwd;
    private ProgressDialog cargando;
    private String parentDbName = "Usuarios";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        BotonInicioSes = (Button)findViewById(R.id.button_login_2);
        log_nmat = (EditText)findViewById(R.id.login_nmat);
        log_pwd = (EditText)findViewById(R.id.login_pwd);
        cargando = new ProgressDialog(this);

        BotonInicioSes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginUsuario();
            }
        });
    }

    private void LoginUsuario() {

        String nmat = log_nmat.getText().toString();
        String pwd = log_pwd.getText().toString();

        if (TextUtils.isEmpty(nmat)){
            Toast.makeText(this, "Debes escribir el numero de matricula...", Toast.LENGTH_SHORT).show();
        }else if (TextUtils.isEmpty(pwd)){
            Toast.makeText(this, "Debes escribir la contrasena...", Toast.LENGTH_SHORT).show();
        }else{
            cargando.setTitle("Iniciando Sesion");
            cargando.setMessage("Por favor, espere");
            cargando.setCanceledOnTouchOutside(false);
            cargando.show();


            Acceso(nmat, pwd);
        }
    }

    private void Acceso(final String nmat,final String pwd) {

        final DatabaseReference Reference;
        Reference = FirebaseDatabase.getInstance().getReference();

        Reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child(parentDbName).child(nmat).exists()){
                    Usuario DatosUsuario = dataSnapshot.child(parentDbName).child(nmat).getValue(Usuario.class);
//                    Comprobacion de cuenta
                    if (DatosUsuario.getMatricula().equals(nmat)){
                        if (DatosUsuario.getPassword().equals(pwd)){
//                            Permito acceso a la cuenta
                            Toast.makeText(LoginActivity.this, "Se ha iniciado sesion correctamente...", Toast.LENGTH_SHORT).show();
                            cargando.dismiss();

                            Intent intent = new Intent(LoginActivity.this, ProductosActivity.class);
                            startActivity(intent);
                        }else{
                            cargando.dismiss();
                            Toast.makeText(LoginActivity.this, "Contraseña Incorrecta...", Toast.LENGTH_SHORT).show();
                        }
                    }
                }else {
                    Toast.makeText(LoginActivity.this, "La cuenta con numero de matricula "+nmat+" no existe", Toast.LENGTH_SHORT).show();
                    cargando.dismiss();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
