package com.example.cateferia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class RegistrarseActivity extends AppCompatActivity {

    private Button BotonCrearCuenta;
    private EditText regist_name, regist_nmat, regist_pwd;
    private ProgressDialog cargando;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrarse);

        BotonCrearCuenta = (Button) findViewById(R.id.button_registrar);
        regist_name =(EditText) findViewById(R.id.registrar_usuario);
        regist_nmat =(EditText)findViewById(R.id.registar_nmat);
        regist_pwd = (EditText)findViewById(R.id.registrar_pwd);
        cargando = new ProgressDialog(this);

        BotonCrearCuenta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreaCuenta();
            }
        });
    }

    private void CreaCuenta(){
        String name = regist_name.getText().toString();
        String nmat = regist_nmat.getText().toString();
        String pwd = regist_pwd.getText().toString();

        if (TextUtils.isEmpty(name)){
            Toast.makeText(this,"Debes ecribir el nombre de usuario...",Toast.LENGTH_SHORT).show();
        }else if (TextUtils.isEmpty(nmat)){
            Toast.makeText(this, "Debes escribir el numero de matricula...", Toast.LENGTH_SHORT).show();
        }else if (TextUtils.isEmpty(pwd)){
            Toast.makeText(this, "Debes escribir la contrasena...", Toast.LENGTH_SHORT).show();
        }else {
            cargando.setTitle("Creando Cuenta...");
            cargando.setMessage("Espere...");
            cargando.setCanceledOnTouchOutside(false);
            cargando.show();

            ValidarNumMatricula(name,nmat, pwd);

        }

    }

    private void ValidarNumMatricula(final String name, final String nmat, final String pwd) {

        final DatabaseReference Reference;
        Reference = FirebaseDatabase.getInstance().getReference();

        Reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(!(dataSnapshot.child("Usuarios").child(nmat).exists())){
                    HashMap<String, Object> data_usuario = new HashMap<>();
                    data_usuario.put("Matricula", nmat);
                    data_usuario.put("Password", pwd);
                    data_usuario.put("Nombre", name);

                    Reference.child("Usuarios").child(nmat).updateChildren(data_usuario).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            if (task.isSuccessful()){
                                Toast.makeText(RegistrarseActivity.this, "Tu cuenta ha sido creada :D", Toast.LENGTH_SHORT).show();
                                cargando.dismiss();

                                Intent intent = new Intent(RegistrarseActivity.this, LoginActivity.class);
                                startActivity(intent);
                            }
                            else{
                                cargando.dismiss();
                                Toast.makeText(RegistrarseActivity.this, "Error, por favor intentelo de nuevo...", Toast.LENGTH_SHORT).show();
                            }

                        }
                    });
                    Toast.makeText(RegistrarseActivity.this, "", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(RegistrarseActivity.this, "El numero de matricula "+nmat+" ya existe", Toast.LENGTH_SHORT).show();
                    cargando.dismiss();
                    Toast.makeText(RegistrarseActivity.this, "Porfavor use otro numero de matricula", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(RegistrarseActivity.this, MainActivity.class);
                    startActivity(intent);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
